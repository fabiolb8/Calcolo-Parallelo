%% Esempio funzionamento

img = imread('esempio_funzionamento.PNG');
image(img)
title('Esempio di funzionamento con 4 processori, in [0,1] con 100000 intervalli');
