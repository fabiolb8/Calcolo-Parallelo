%% Esempio funzionamento

img = imread('esempio_funzionamento.PNG');
image(img)
title('Esempio di funzionamento con 4 processori e dimensione dei vettori pari a 100000');
